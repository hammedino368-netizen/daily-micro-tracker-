# Daily Micro Tracker - Backend

Instructions: set environment variables and run `npm install` then `npm start`.
