-- init.sql for Daily Micro Tracker
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password_hash TEXT,
  role VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS borrowers (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(100),
  phone VARCHAR(20),
  address TEXT,
  guarantor_name VARCHAR(100),
  guarantor_phone VARCHAR(20),
  created_by INT REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS loans (
  id SERIAL PRIMARY KEY,
  borrower_id INT REFERENCES borrowers(id),
  principal_amount DECIMAL(12,2),
  interest_rate DECIMAL(5,2),
  start_date DATE,
  due_date DATE,
  repayment_frequency VARCHAR(20),
  status VARCHAR(20) DEFAULT 'active',
  created_by INT REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS repayments (
  id SERIAL PRIMARY KEY,
  loan_id INT REFERENCES loans(id),
  officer_id INT REFERENCES users(id),
  amount_paid DECIMAL(12,2),
  payment_date DATE,
  payment_method VARCHAR(20),
  remarks TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS savings (
  id SERIAL PRIMARY KEY,
  borrower_id INT REFERENCES borrowers(id),
  amount DECIMAL(12,2),
  transaction_type VARCHAR(10),
  officer_id INT REFERENCES users(id),
  transaction_date DATE,
  remarks TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  action_type VARCHAR(50),
  entity VARCHAR(50),
  entity_id INT,
  details TEXT,
  timestamp TIMESTAMP DEFAULT NOW()
);
