# Daily Micro Tracker - Frontend

Simple React skeleton. Replace with full UI from the template guide.
