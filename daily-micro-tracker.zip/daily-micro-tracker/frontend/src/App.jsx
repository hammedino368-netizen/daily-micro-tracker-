import React from 'react';
export default function App(){
  return (
    <div style={{fontFamily:'Arial, Helvetica, sans-serif', padding:20}}>
      <h1>Daily Micro Tracker - Frontend</h1>
      <p>Replace this with the full React app. Configure REACT_APP_API_URL in .env when deploying.</p>
    </div>
  );
}
